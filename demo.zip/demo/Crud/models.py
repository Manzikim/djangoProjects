from django.db import models

# Create your models here.
class Album(models.Model):
    name = models.CharField(max_length=100)
    gender = models.CharField(max_length=1)
    release_date = models.DateField()
    num_stars = models.IntegerField()

    def __str__(self):
        return self.name
    