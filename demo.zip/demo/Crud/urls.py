from django.urls import path
from . import views

urlpatterns = [
    path('',views.Album_list,name='album_list'),
    path('detail/<int:pk>/',views.album_detail,name='album_detail'),

]
