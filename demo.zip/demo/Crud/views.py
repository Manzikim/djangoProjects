from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from django.core.paginator import Paginator
from .models import Album
from .serializers import AlbumSerializer
# Create your views here.

@api_view(['GET','POST'])
def Album_list(request):
    if request.method == 'GET':
        album = Album.objects.all()
        paginator = Paginator(album,10)
        page_number = request.GET.get('page')
        page_obj = paginator.get_page(page_number)
        serializer = AlbumSerializer(page_obj, many=True)
        return Response(serializer.data)

    elif request.method == 'POST':
        serializer = AlbumSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'message':f"Album '{serializer.validated_data['name']}' created"}, status=status.HTTP_201_CREATED)
        else:
            return Response({'error':'Invalid data. If the problem persists contact support@email.com'}, status=status.HTTP_400_BAD_REQUEST)

@api_view(['GET','PUT','DELETE'])
def album_detail(request, pk):
    try:
        album = Album.objects.get(pk=pk)
    except Album.DoesNotExist:
        return Response({'error':'Album not found. Try to refresh the page and if the problem persists contact support@email.com'}, status=status.HTTP_404_NOT_FOUND)

    if request.method == 'GET':
        serializer = AlbumSerializer(album)
        return Response(serializer.data)
    
    elif request.method =='PUT':
        serializer = AlbumSerializer(album, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'message': f"Album '{serializer.validated_data['name']}' updated"})
        else:
            return Response({'error':'Invalid data. If the problem persists contact support@email.com'}, status=status.HTTP_400_BAD_REQUEST)

    elif request.method == 'DELETE':
        album.delete()
        return Response({'message':f"Album '{album.name}' deleted. "}, status=status.HTTP_204_NO_CONTENT)
